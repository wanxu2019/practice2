# 创新方法平台Tomcat使用说明

创新方法平台Tomcat是基于Tomcat8.0.47进行修改的。（只是加入了部分lib和配置文件）

## 使用说明

1. 首先将该项目Clone到本地。
2. 启用Eclipse或者Idea等Tomcat开发环境，选择当前的Tomcat。不要修改conf/web.xml和conf/context.xml两个文件。如果出现与远程端不同步的情况。请接受远程端最新的配置。


## 版本说明 

### v0.6 更新 `2018年4月10日`

1. 增加了用户数据库自定义的功能。
    在前一个版本，用户信息数据库保存在2服务器上，导致断网无法使用登录功能，本次更新在`conf/context.xml`文件中增加配置功能。
    对应的配置片段
    ``` xml
     <Resource
        name="jdbc/userInfo"                                                             
        auth="Container"       
        type ="javax.sql.DataSource"        
        driverClassName = "com.mysql.jdbc.Driver"       
        url = "jdbc:mysql://115.154.191.2:3306/innovation_user_info?characterEncoding=utf-8"            
        username = "xjtucad"                   
        password = "xjtucad"                 
    />
    ```
    可修改部分对应的注释

    `driverClassName`:数据库链接驱动

    `url`:数据库连接URL

    `username`:数据库用户名

    `password`:数据库密码
    
    如果使用本地数据库可以将`url`修改为:`jdbc:mysql://localhost:3306/innovation_user_info?characterEncoding=utf-8`

    **重要**
    如果配置文件出现问题(配置格式错误或者未配置)或者数据库无法链接，会使用程序内的配置文件，程序内默认的配置
    ``` java 
    private String url = "jdbc:mysql://115.154.191.2:3306/innovation_user_info?useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT";
    //用户名
    private String user = "xjtucad";
    //用户密码
    private String pwd = "xjtucad";
    ```
2. 用户数据库介绍：
    用户信息数据库编码格式为`utf-8`
    用户数据库的创建表的语句为：
    ``` sql

        DROP TABLE IF EXISTS `user_info`;
        /*!40101 SET @saved_cs_client     = @@character_set_client */;
        /*!40101 SET character_set_client = utf8 */;
        CREATE TABLE `user_info` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(255) DEFAULT NULL,
        `password` varchar(255) DEFAULT NULL,
        `domain` varchar(255) DEFAULT NULL,
        `permission` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `telphone` varchar(255) DEFAULT NULL,
        `personName` varchar(255) DEFAULT NULL,
        `jobNumber` varchar(255) DEFAULT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
        /*!40101 SET character_set_client = @saved_cs_client */;

        --
        -- Dumping data for table `user_info`
        --

        LOCK TABLES `user_info` WRITE;
        /*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
        INSERT INTO `user_info` VALUES (1,'admin','admin','0','superAdmin','cad@xjtu.edu.cnasd','13022952582asd','nullasdasd','123123'),(2,'123','123','1','admin','cad@xjtu.edu.cn','13022952582',NULL,NULL),(3,'111','111','1','user','cad@xjtu.edu.cn','13022952582','',''),(4,'222','222','1','user','cad@xjtu.edu.cn','13022952582',NULL,NULL),(5,'333','333','1','user','cad@xjtu.edu.cn','13022952582',NULL,NULL);
        /*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
        UNLOCK TABLES;

    ```

    该语句会生成对应的用户信息表，同时新建5个用户。

    |用户名|密码|权限|
    |--|--|--|
    |admin|admin|超级管理员|
    |123|123|管理员|
    |111|111|普通用户|
    |222|222|普通用户|
    |333|333|普通用户|

### v0.5

**重要：之前版本的功能全部丢弃**

为了单个Tomcat的稳定性
目前采用TokenManger单例模式实现单个tomcat内所有APP的统一登录，后续功能有待添加。
当前登录必须集成集成并启动静态资源即webresouces目录内的文件。

1. 登录操作是在当前的url后添加.login,跳转到webresouces/login.html实现的。

2. 退出操作仍然是采用清除当前页面的cookie内的token。然后刷新当前页面


3. 后台获取用户信息的操作，
``` java
  import xjtucad.model.User;

  User userinfo = (User) httpSession.getAttribute("userInfo");
```
这里的User对象，是在tomcat/lib文件中的`tomcat-sso.jar`中一个类，如果引用了tomcat 的lib就可以使用`import`

支持的方法包括
``` java
package xjtucad.model;

import java.io.Serializable;

public class User implements Serializable{
    private Integer id;

    private String username;

    private String password;

    private String domain;

    private String permission;

    private String email;

    private String telphone;
    private String personName;
    private String jobNumber;
    private String domainName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain == null ? null : domain.trim();
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission == null ? null : permission.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getTelphone() {
        return telphone;
    }

    public void setTelphone(String telphone) {
        this.telphone = telphone == null ? null : telphone.trim();
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", domain='" + domain + '\'' +
                ", permission='" + permission + '\'' +
                ", email='" + email + '\'' +
                ", telphone='" + telphone + '\'' +
                ", personName='" + personName + '\'' +
                ", jobNumber='" + jobNumber + '\'' +
                ", domainName='" + domainName + '\'' +
                '}';
    }
}
```

 4. 配置了全局过滤器，全局过滤器的目标是过滤模板项目（模板项目需要统一命名为CAI-XXX），
    1. 对于模板来说,Tomcat配置了如果没有登录就会自动跳转的过滤器。
    2. 其他操作由开发人员根据权限判断。

5. 目前登录的存活期与Session同步，关闭重启tomcat后或关闭浏览器再打开以后就登录失效。

